import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddAdminComponent } from './user/admin/add-admin/add-admin.component';
import { EditAdminComponent } from './user/admin/edit-admin/edit-admin.component';
import { ListAdminComponent } from './user/admin/list-admin/list-admin.component';
import { AddCabComponent } from './user/driver/add-cab/add-cab.component';
import { EditCabComponent } from './user/driver/edit-cab/edit-cab.component';
import { ListCabComponent } from './user/driver/list-cab/list-cab.component';
import { AddCustomerComponent } from './user/customer/add-customer/add-customer.component';
import { EditCustomerComponent } from './user/customer/edit-customer/edit-customer.component';
import { ListCustomerComponent } from './user/admin/list-customer/list-customer.component';
import { AddDriverComponent } from './user/driver/add-driver/add-driver.component';
import { EditDriverComponent } from './user/driver/edit-driver/edit-driver.component';
import { ListDriverComponent } from './user/admin/list-driver/list-driver.component';
import { AddTripComponent } from './user/customer/add-trip/add-trip.component';
import { ListTripComponent } from './user/driver/list-trip/list-trip.component';
import { HeaderComponent } from './header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './registration/login/login.component';
import { LogoutComponent } from './registration/logout/logout.component';
import { RegisterComponent } from './registration/register/register.component';
import { AdminRegisterComponent } from './registration/admin-register/admin-register.component';
import { CustomerRegisterComponent } from './registration/customer-register/customer-register.component';
import { DriverRegisterComponent } from './registration/driver-register/driver-register.component';
import { ViewBestDriversComponent } from './user/customer/view-best-drivers/view-best-drivers.component';
import { CarouselComponent } from './carousel/carousel.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { CountcabComponent } from './user/driver/countcab/countcab.component';
import { MybookingsComponent } from './user/customer/mybookings/mybookings.component';
import { AboutComponent } from './about/about.component';
import { ViewalltripsComponent } from './user/admin/viewalltrips/viewalltrips.component';







@NgModule({
  declarations: [
    AppComponent,
    AddAdminComponent,
    EditAdminComponent,
    ListAdminComponent,
    AddCabComponent,
    EditCabComponent,
    ListCabComponent,
    AddCustomerComponent,
    EditCustomerComponent,
    ListCustomerComponent,
    AddDriverComponent,
    EditDriverComponent,
    ListDriverComponent,
    AddTripComponent,
    ListTripComponent,
    HeaderComponent,
    LoginComponent,
    LogoutComponent,
    RegisterComponent,
    AdminRegisterComponent,
    CustomerRegisterComponent,
    DriverRegisterComponent,
    ViewBestDriversComponent,
    CarouselComponent,
    HomeComponent,
    ContactComponent,
    CountcabComponent,
    MybookingsComponent,
    AboutComponent,
    ViewalltripsComponent,
    
    
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
