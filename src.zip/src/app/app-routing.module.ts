import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminRegisterComponent } from './registration/admin-register/admin-register.component';
import { CustomerRegisterComponent } from './registration/customer-register/customer-register.component';
import { DriverRegisterComponent } from './registration/driver-register/driver-register.component';
import { LoginComponent } from './registration/login/login.component';
import { LogoutComponent } from './registration/logout/logout.component';
import { AddAdminComponent } from './user/admin/add-admin/add-admin.component';
import { EditAdminComponent } from './user/admin/edit-admin/edit-admin.component';
import { ListAdminComponent } from './user/admin/list-admin/list-admin.component';
import { AddCustomerComponent } from './user/customer/add-customer/add-customer.component';
import { EditCustomerComponent } from './user/customer/edit-customer/edit-customer.component';
import { ListCustomerComponent } from './user/admin/list-customer/list-customer.component';
import { AddDriverComponent } from './user/driver/add-driver/add-driver.component';
import { EditDriverComponent } from './user/driver/edit-driver/edit-driver.component';
import { ListDriverComponent } from './user/admin/list-driver/list-driver.component';
import { AddTripComponent } from './user/customer/add-trip/add-trip.component';
import { ListTripComponent } from './user/driver/list-trip/list-trip.component';
import { ViewBestDriversComponent } from './user/customer/view-best-drivers/view-best-drivers.component';
import { AddCabComponent } from './user/driver/add-cab/add-cab.component';
import { EditCabComponent } from './user/driver/edit-cab/edit-cab.component';
import { ListCabComponent } from './user/driver/list-cab/list-cab.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { CarouselComponent } from './carousel/carousel.component';
import { CountcabComponent } from './user/driver/countcab/countcab.component';
import { MybookingsComponent } from './user/customer/mybookings/mybookings.component';
import { AboutComponent } from './about/about.component';
import { ViewalltripsComponent } from './user/admin/viewalltrips/viewalltrips.component';



const routes: Routes = [
  {
    path : 'add-admin', component : AddAdminComponent
  },
 
 
  {
    path : 'add-customer', component : AddCustomerComponent
  },
  {
    path : 'edit-customer/:userId', component : EditCustomerComponent
  },
 
  {
    path : 'add-driver', component : AddDriverComponent
  },
 
  {
    path : 'list-driver', component : ListDriverComponent
  },
  
  {
    path : 'authenticate', component : LoginComponent
  },
  {
    path : 'logout', component : LogoutComponent
  },
  {
    path: 'adminreg', component : AdminRegisterComponent
  },
  {
    path: 'customerreg', component : CustomerRegisterComponent
  },
  {
    path: 'driverreg', component : DriverRegisterComponent
  },
  {
    path: 'add-trip/:userId', component : AddTripComponent
  },
  {
    path: 'best-drivers', component : ViewBestDriversComponent
  },
  {
    path: 'list-customer', component : ListCustomerComponent
  },
  {
    path: 'list-driver', component :ListDriverComponent
  },
  {
    path: 'edit-driver/:userId', component : EditDriverComponent
  },
  {
    path: 'add-cab', component : AddCabComponent
  },
  {
    path: 'edit-cab/:cabId', component : EditCabComponent
  },
  {
    path: 'list-cab', component : ListCabComponent
  },
  {
    path: 'list-trip/:userId', component : ListTripComponent
  },
  {
    path: 'home', component : HomeComponent
  },
  {
    path: 'contact', component : ContactComponent
  },
  {
    path: '', component : CarouselComponent
  },
  {
    path: 'count-cab', component : CountcabComponent
  },
  {
    path: 'my-bookings/:userId', component : MybookingsComponent
  },
  {
    path: 'about', component : AboutComponent
  },
  {
    path: 'alltrips', component : ViewalltripsComponent 
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
