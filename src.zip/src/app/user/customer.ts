import { User } from "./user";

export interface Customer {
    customerId : number,
    userId: User,
    customerUserName : string,
    customerPassword: string,
    customerAddress: string,
    customerMobileNumber : number,
    customerEmail : string
}