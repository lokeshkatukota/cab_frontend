import { User } from "./user";

export interface Admin {
    adminId: number,
    userId: User,
    adminUserName : string,
    adminPassword: string,
    adminAddress: string,
    adminMobileNumber : number,
    adminEmail : string
}