import { Component, OnInit } from '@angular/core';
import { Trip } from '../../trip/trip';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-viewalltrips',
  templateUrl: './viewalltrips.component.html',
  styleUrls: ['./viewalltrips.component.css']
})
export class ViewalltripsComponent implements OnInit {

  allTrips:Trip[]=[];

  myTrip: Trip= {
      tripBookingId: 0,
      fromLocation: '',
      toLocation: '',
      fromDateTime: '',
      toDateTime: '',
      distanceInKm:0,
      bill:0,
      status : '',
      
      customerEntity:{
        customerId: 0,
        userId:{
          userId:0,
          username: '',
          password:'',
          role: 'customer'
        },
        customerUserName:'',
        customerPassword:'',
        customerAddress:'',
        customerMobileNumber:0,
        customerEmail:''
      },
      driverEntity:{
        driverId: 0,
        userId:{
          userId:0,
          username: '',
          password:'',
          role: 'driver'
        },
        driverUserName:'',
        driverPassword:'',
        driverAddress:'',
        driverMobileNumber:0,
        driverEmail:'',
        driverLicenceNumber:0,
        driverRating:0,
        cab:{
          cabId:0,
          carType:'',
          perKmRate:15,
        }
      }
  }
  

  constructor(private userService:UserService) { }

  ngOnInit(): void {
    this.userService.viewAllTrips().subscribe((response) => {
      this.allTrips=response;
    });
  }

  deleteTrip(tripId: number){
    this.userService.deleteTrip(tripId).subscribe((response) => {
      console.log(response);
      this.myTrip = response;
    });
  }

 
}
