import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewalltripsComponent } from './viewalltrips.component';

describe('ViewalltripsComponent', () => {
  let component: ViewalltripsComponent;
  let fixture: ComponentFixture<ViewalltripsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewalltripsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewalltripsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
