import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../../customer';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-list-customer',
  templateUrl: './list-customer.component.html',
  styleUrls: ['./list-customer.component.css']
})
export class ListCustomerComponent implements OnInit {

  allCustomers: Customer[] = [];  

  myCustomer: Customer= {
    customerId : 0,
    userId:{
      userId:0,
      username:'',
      password:'',
      role:"customer"
    },
    customerUserName: '',
    customerPassword: '',
    customerAddress: '',
    customerMobileNumber: 0,
    customerEmail: ''
}
  
 

  myError = '';
  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
    this.userService.getAllCustomers().subscribe((response) => {
      console.log(response);
      this.allCustomers = response;
    },
    (error) => {
      console.log(error.error.message);
      this.myError = error.error.message;
    });
    console.log("this is after the asynchronous call");
    
  }

  deleteCustomer(customerId: number){
    console.log(customerId);
    this.userService.deleteCustomer(customerId).subscribe((response) => {
      console.log(response);
      this.myCustomer= response;
    },
    (error) => {
      console.log(error.error.message);
      this.allCustomers = [];
      this.myError = error.error.message;
    });
  }

  
 
}
