import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Driver } from '../../driver';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-list-driver',
  templateUrl: './list-driver.component.html',
  styleUrls: ['./list-driver.component.css']
})
export class ListDriverComponent implements OnInit {

  allDrivers: Driver[] = [];  

  myDriver: Driver={
    driverId: 0,
    userId:{
      userId : 0,
      username:'',
      password:'',
      role:"driver"
    },
    cab:{
      cabId:0,
      carType:'',
      perKmRate:0
    },
    driverUserName: '',
    driverPassword: '',
    driverAddress: '',
    driverMobileNumber: 0,
    driverEmail: '',
    driverLicenceNumber:0,
    driverRating:0
}
  
  myError = '';
  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
    this.userService.getAllDrivers().subscribe((response) => {
      console.log(response);
      this.allDrivers = response;
    },
    (error) => {
      console.log(error.error.message);
      this.myError = error.error.message;
    });
    console.log("this is after the asynchronous call");
    
  }

  deleteDriver(driverId: number){
    console.log(driverId);
    this.userService.deleteDriver(driverId).subscribe((response) => {
      console.log(response);
      this.myDriver= response;
    },
    (error) => {
      console.log(error.error.message);
      this.allDrivers = [];
      this.myError = error.error.message;
    });
  }

}
