import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-admin',
  templateUrl: './edit-admin.component.html',
  styleUrls: ['./edit-admin.component.css']
})
export class EditAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
