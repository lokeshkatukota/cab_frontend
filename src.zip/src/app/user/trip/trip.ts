import { DatePipe } from "@angular/common";
import { Customer } from "../customer";
import { Driver } from "../driver";

export interface Trip {
    tripBookingId : number,
    fromLocation: string,
    toLocation : string,
    fromDateTime: string,
    toDateTime: string,
    distanceInKm : number,
    bill : number,
    customerEntity : Customer,
    driverEntity : Driver,
    status : string
}
