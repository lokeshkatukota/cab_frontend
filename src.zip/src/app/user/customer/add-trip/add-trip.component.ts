import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Driver } from '../../driver';
import { Trip } from '../../trip/trip';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-add-trip',
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {

  allDriversList : Driver[]=[]
  i=0;
  addTripData: Trip = {
    tripBookingId: 0,
    fromLocation: '',
    toLocation: '',
    fromDateTime: '',
    toDateTime: '',
    distanceInKm:0,
    bill:0,
    status : '',
    
    customerEntity:{
      customerId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'customer'
      },
      customerUserName:'',
      customerPassword:'',
      customerAddress:'',
      customerMobileNumber:0,
      customerEmail:''
    },
    driverEntity:{
      driverId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'driver'
      },
      driverUserName:'',
      driverPassword:'',
      driverAddress:'',
      driverMobileNumber:0,
      driverEmail:'',
      driverLicenceNumber:0,
      driverRating:0,
      cab:{
        cabId:0,
        carType:'',
        perKmRate:15,
      }
    }
}
  constructor(private userService:UserService , private router: Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let userId :any = this.activatedRoute.snapshot.paramMap.get('userId');
    console.log(userId);
 
      this.userService.getCustomer(userId).subscribe((newCustomer) => {
      console.log(newCustomer);
      this.addTripData.customerEntity=newCustomer;

      this.userService.getAllDrivers().subscribe((response) => {
      console.log(response);
      this.allDriversList = response;

      });
      
    });

  }

  addTripInfo(){
    let date: Date = new Date(); 
    let d=date.toString();
  
   if(d > this.addTripData.toDateTime){
      this.addTripData.status= "COMPLETED ";
   }
   if( this.addTripData.fromDateTime < d  ){
     this.addTripData.status= "BOOKED"
   }

   this.addTripData.bill= this.addTripData.distanceInKm * this.addTripData.driverEntity.cab.perKmRate;


    for(this.i=0;this.i<this.allDriversList.length;this.i++) {
      if(this.allDriversList[this.i].driverId==this.addTripData.driverEntity.driverId) {
        this.addTripData.driverEntity={...this.allDriversList[this.i]};
        break;
      }
    }
    console.log(this.addTripData);
    this.userService.addTripInfo(this.addTripData).subscribe((response: any) => {
      console.log(response);
      //this.router.navigate(['home']); 
    });

    }
    
  

}


