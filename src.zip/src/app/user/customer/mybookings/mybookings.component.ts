import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../../trip/trip';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-mybookings',
  templateUrl: './mybookings.component.html',
  styleUrls: ['./mybookings.component.css']
})
export class MybookingsComponent implements OnInit {

   myError='';

   allTripsList: Trip[]=[];

   addTripData: Trip = {
    tripBookingId: 0,
    fromLocation: '',
    toLocation: '',
    fromDateTime: '',
    toDateTime: '',
    distanceInKm:0,
    bill:0,
    status : '',
    
    customerEntity:{
      customerId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'customer'
      },
      customerUserName:'',
      customerPassword:'',
      customerAddress:'',
      customerMobileNumber:0,
      customerEmail:''
    },
    driverEntity:{
      driverId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'driver'
      },
      driverUserName:'',
      driverPassword:'',
      driverAddress:'',
      driverMobileNumber:0,
      driverEmail:'',
      driverLicenceNumber:0,
      driverRating:0,
      cab:{
        cabId:0,
        carType:'',
        perKmRate:0,
      }
    }
}

  constructor(private userService:UserService , private router: Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let userId :any = this.activatedRoute.snapshot.paramMap.get('userId');
    console.log(userId);
 
      this.userService.getCustomer(userId).subscribe((newCustomer) => {
      console.log(newCustomer);
      this.addTripData.customerEntity.customerId=newCustomer.customerId;

      this.userService.getCustomerTrips(this.addTripData.customerEntity.customerId).subscribe((response) =>{
        this.allTripsList=response;
        
      },
      (error) => {
        console.log(error.error.message);
        this.myError = error.error.message;
      });
  });

}

}