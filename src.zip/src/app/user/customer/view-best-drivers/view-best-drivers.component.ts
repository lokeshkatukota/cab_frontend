import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Driver } from '../../driver';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-view-best-drivers',
  templateUrl: './view-best-drivers.component.html',
  styleUrls: ['./view-best-drivers.component.css']
})
export class ViewBestDriversComponent implements OnInit {

  myError= '';
  allDrivers: Driver[] = [] 

  constructor(private userService:UserService,private router:Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    
    this.userService.getBestDrivers().subscribe((response) => {
      console.log(response);
      this.allDrivers = response;
      
    },
    (error) => {
      console.log(error.error.message);
      this.myError = error.error.message;
    });
  }
  
}
