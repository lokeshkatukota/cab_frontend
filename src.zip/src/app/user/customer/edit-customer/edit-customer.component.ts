import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../../customer';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditCustomerComponent implements OnInit {

  constructor(private userService:UserService, 
    private activatedRoute: ActivatedRoute, 
    private router : Router) { }

    newCustomer: Customer = {
      customerId : 0,
      userId:{
        userId: 0,
        username:'',
        password:'',
        role:'customer'
      },
      customerUserName: '',
      customerPassword: '',
      customerAddress: '',
      customerMobileNumber: 0,
      customerEmail: ''
  }
  ngOnInit(): void {
    
    let userId :any = this.activatedRoute.snapshot.paramMap.get('userId');
         console.log(userId);

            this.userService.getCustomer(userId).subscribe((newCustomer) => {
              console.log(newCustomer);
              this.newCustomer=newCustomer;
            
    });

 

  }

  editCustomer(myForm: NgForm){
    console.log(myForm);
    let newUpdateCustomer:Customer= {
      customerId: this.newCustomer.customerId,
     userId: this.newCustomer.userId,
      customerUserName :this.newCustomer.customerUserName,
      customerPassword: this.newCustomer.customerPassword,
      customerAddress: this.newCustomer.customerAddress,
      customerMobileNumber : this.newCustomer.customerMobileNumber,
      customerEmail : this.newCustomer.customerEmail
    }
    this.userService.updateCustomer(newUpdateCustomer).subscribe((response) =>{
      console.log(response);
      this.router.navigate(['home']);
    });
  }

}
