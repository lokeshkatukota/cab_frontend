import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../../customer';
import { UserService } from '../../user.service';


@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {

  addCustomerData: Customer = {
    customerId : 0,
    userId:{
      userId: 0,
      username:'',
      password:'',
      role:'customer'
    },
    customerUserName: '',
    customerPassword: '',
    customerAddress: '',
    customerMobileNumber: 0,
    customerEmail: ''
}
  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
  }

  // addCustomerInfo(myForm: NgForm){
  //   console.log(myForm);
  //   let myCustomer = {
  //    customerId: this.addCustomerData.customerId,
  //    userId: this.addCustomerData.userId,
  //     customerUserName :this.addCustomerData.customerUserName,
  //     customerPassword: this.addCustomerData.customerPassword,
  //     customerAddress: this.addCustomerData.customerAddress,
  //     customerMobileNumber : this.addCustomerData.customerMobileNumber,
  //     customerEmail : this.addCustomerData.customerEmail

  //   }
  //   //this.allProducts.push(myProduct);
  //   this.userService.addCustomerInfo(myCustomer).subscribe((response) => {
  //     console.log(response);
  //     //this.router.navigate(['list-product']);
  //   });

    
  // }

}
