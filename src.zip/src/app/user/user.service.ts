import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import { AuthService } from '../registration/auth.service';
import { Cab } from './driver/cab';
import { Driver } from './driver';
import { Trip } from './trip/trip';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient,
    private authService: AuthService) { }

  getHttpOptions() {
    let httpOptions = {};
    let userData: any = '';
    userData = this.authService.retrieveUserDetails();
    if (userData != null) {
      let token = JSON.parse(userData).token;
      console.log("token:" + token);
      httpOptions = {
        headers: new HttpHeaders({
          'content-type': 'application/json',
          'Authorization': 'Bearer ' + token
        })
      }
    }
    return httpOptions;
  }

  //CUSTOMER UPDATION ENDPOINTS

  // 1. GETTING USERID BY CUSTOMERUSERNAME THROUGH QUERY -----remove this
  getUserId(customerName: string): Observable<number>{
    return this.http.get<number>("http://localhost:8040/api/user/getuserid/" +customerName,this.getHttpOptions());

  }

  // 2. GETTING ONE CUSTOMER DETAIL BY PASSING ABOVE USERID THROUGH QUERY
  getCustomer(userId: number): Observable<Customer>{
       return this.http.get<Customer>("http://localhost:8040/api/customer/getdetails/"+ userId,this.getHttpOptions());

  }

  // 3. UPDATING THE CUSTOMER DETAILS 
  updateCustomer(updateCustomer :Customer) :Observable<Customer[]>{
      return this.http.put<Customer[]>("http://localhost:8040/api/customer/update",updateCustomer,this.getHttpOptions());

  }

  //LISTING THE CUSTOMERS
  getAllCustomers(): Observable<Customer[]>{
    return  this.http.get<Customer[]>("http://localhost:8040/api/customer/getall",this.getHttpOptions());
  }

  //DELETING THE CUSTOMER
  deleteCustomer(customerId:number):Observable<Customer>{
    return  this.http.delete<Customer>("http://localhost:8040/api/customer/delete/"+customerId,this.getHttpOptions());
  }

 //ADDING A CAB
 addCabInfo(newCab: Cab): Observable<Cab>{
  return this.http.post<Cab>("http://localhost:8040/api/cab/add",newCab, this.getHttpOptions());
}

//GET A CAB
getCab(cabId:number):Observable<Cab[]>{
  return  this.http.get<Cab[]>("http://localhost:8040/api/cab/getone/"+cabId,this.getHttpOptions());
}

//GET ALL CABS
getAllCabs(): Observable<Cab[]>{
  return  this.http.get<Cab[]>("http://localhost:8040/api/cab/getall",this.getHttpOptions());
}

//UPDATE CAB
updateCab(updateCab :Cab) :Observable<Cab[]>{
  return this.http.put<Cab[]>("http://localhost:8040/api/cab/update",updateCab,this.getHttpOptions());

}

//DELETE A CAB
deleteCab(cabId:number):Observable<Cab>{
  return  this.http.delete<Cab>("http://localhost:8040/api/cab/delete/" +cabId,this.getHttpOptions());
}

//GET ALL DRIVERS
getAllDrivers(): Observable<Driver[]>{
  return  this.http.get<Driver[]>("http://localhost:8040/api/driver/getall",this.getHttpOptions());
}

//DELETING THE DRIVER
deleteDriver(driverId:number):Observable<Driver>{
  return  this.http.delete<Driver>("http://localhost:8040/api/driver/delete/"+ driverId,this.getHttpOptions());
}

// GETTING ONE DRIVER DETAIL BY PASSING ABOVE USERID THROUGH QUERY
getDriver(userId: number): Observable<Driver>{
  return this.http.get<Driver>("http://localhost:8040/api/driver/getdetails/"+ userId,this.getHttpOptions());

}

// UPDATING THE DRIVER DETAILS 
updateDriver(updateDriver :Driver) :Observable<Driver[]>{
 return this.http.put<Driver[]>("http://localhost:8040/api/driver/update",updateDriver,this.getHttpOptions());

}

//BOOKING A TRIP
addTripInfo(newTrip: Trip): Observable<Trip>{
  return this.http.post<Trip>("http://localhost:8040/api/trips/add",newTrip, this.getHttpOptions());
}

//GET BEST DRIVERS
getBestDrivers(): Observable<Driver[]>{
  return this.http.get<Driver[]>("http://localhost:8040/api/driver/bestdrivers",this.getHttpOptions());

}

//GET COUNT OF CAB TYPE
getCountCarsOfType(carType : string): Observable<number>{
  return this.http.get<number>("http://localhost:8040/api/cab/count/" + carType,this.getHttpOptions());

}

//GET TRIPS OF A CUSTOMER
getCustomerTrips(customerId : number): Observable<Trip[]>{
  return this.http.get<Trip[]>("http://localhost:8040/api/trips/getcustomertrips/" + customerId,this.getHttpOptions());

}

//GET TRIPS OF A DRIVER
getDriverTrips(driverId : number): Observable<Trip[]>{
  return this.http.get<Trip[]>("http://localhost:8040/api/trips/getdrivertrips/" + driverId,this.getHttpOptions());

}

//VIEW ALL THE TRIPS (WITH CUSTOMER AND DRIVER DETAILS)
viewAllTrips() : Observable<Trip[]> {
  return this.http.get<Trip[]>("http://localhost:8040/api/trips/viewalltrips",this.getHttpOptions())
}

//DELETE A TRIP
deleteTrip(tripbookingId: number): Observable<Trip> {
  return this.http.delete<Trip>("http://localhost:8040/api/trips/delete/" + tripbookingId,this.getHttpOptions())
}

}
