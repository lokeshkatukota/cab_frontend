import { Cab } from "./driver/cab";
import { User } from "./user";

export interface Driver {
    driverId: number,
    userId: User,
    cab : Cab,
    driverUserName : string,
    driverPassword: string,
    driverAddress: string,
    driverMobileNumber : number,
    driverEmail : string,
    driverLicenceNumber: number,
    driverRating : number
    
}