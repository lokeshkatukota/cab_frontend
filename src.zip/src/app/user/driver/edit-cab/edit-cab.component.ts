import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../user.service';
import { Cab } from '../cab';

@Component({
  selector: 'app-edit-cab',
  templateUrl: './edit-cab.component.html',
  styleUrls: ['./edit-cab.component.css']
})
export class EditCabComponent implements OnInit {

  editForm: FormGroup;

  constructor(private userService: UserService, 
                private activatedRoute: ActivatedRoute,
                private router: Router) { 

    this.editForm = new FormGroup({
     cabId: new FormControl(),
      carType: new FormControl(),
      perKmRate: new FormControl()
    })
  }

  ngOnInit(): void {
    let cabId: any = this.activatedRoute.snapshot.paramMap.get('cabId');

    this.userService.getCab(cabId).subscribe((response) => {
      this.editForm.setValue(response);
    });
    
  }

  editCab(){
    console.log(this.editForm);
    this.userService.updateCab(this.editForm.value).subscribe((response) => {
      console.log(response);
      this.router.navigate(['list-cab']);
    });
    
  }

}
