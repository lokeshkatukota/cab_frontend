import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Driver } from '../../driver';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-edit-driver',
  templateUrl: './edit-driver.component.html',
  styleUrls: ['./edit-driver.component.css']
})
export class EditDriverComponent implements OnInit {
  constructor(private userService:UserService, 
    private activatedRoute: ActivatedRoute, 
    private router : Router) { }

    newDriver: Driver = {
      driverId : 0,
      userId:{
        userId: 0,
        username:'',
        password:'',
        role:'driver'
      },
      cab:{
        cabId: 0,
        carType:'',
        perKmRate:0,
      },
      driverUserName: '',
      driverPassword: '',
      driverAddress: '',
      driverMobileNumber: 0,
      driverEmail: '',
      driverLicenceNumber:0,
      driverRating:0
  }
  ngOnInit(): void {
    
    let userId :any = this.activatedRoute.snapshot.paramMap.get('userId');
   console.log(userId);

            this.userService.getDriver(userId).subscribe((newDriver) => {
              console.log(newDriver);
              this.newDriver=newDriver;     
    });
  }

  editDriver(myForm: NgForm){
    console.log(myForm);
    let newUpdateDriver:Driver= {
      driverId: this.newDriver.driverId,
      userId: this.newDriver.userId,
      cab: this.newDriver.cab,
      driverUserName :this.newDriver.driverUserName,
      driverPassword: this.newDriver.driverPassword,
      driverAddress: this.newDriver.driverAddress,
      driverMobileNumber : this.newDriver.driverMobileNumber,
      driverEmail : this.newDriver.driverEmail,
      driverLicenceNumber:this.newDriver.driverLicenceNumber,
      driverRating: this.newDriver.driverRating
    }
    this.userService.updateDriver(newUpdateDriver).subscribe((response) =>{
      console.log(response);
      this.router.navigate(['home']);
    });
  }

}
