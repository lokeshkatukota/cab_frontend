export interface Cab {
    cabId :number,
    carType: string,
    perKmRate: number
}