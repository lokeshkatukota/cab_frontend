import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';
import { Cab } from '../cab';

@Component({
  selector: 'app-add-cab',
  templateUrl: './add-cab.component.html',
  styleUrls: ['./add-cab.component.css']
})
export class AddCabComponent implements OnInit {

  // addCabData: Cab= {
  //   cabId: 0,
  //   carType: '',
  //   perKmRate: 0

  // }
  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
  }

  // addCab(myForm: NgForm) {
  //   console.log(myForm);
  //     let myCab = {
  //      cabId: this.addCabData.cabId,
  //      carType: this.addCabData.carType,
  //      perKmRate :this.addCabData.perKmRate
  //     }
  //     //this.allProducts.push(myProduct);
  //     this.userService.addCabInfo(myCab).subscribe((response) => {
  //       console.log(response);
  //       //this.router.navigate(['authenticate']);
  //     });

  // }

}
