import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListCabComponent } from './list-cab.component';

describe('ListCabComponent', () => {
  let component: ListCabComponent;
  let fixture: ComponentFixture<ListCabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListCabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListCabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
