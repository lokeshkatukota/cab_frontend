import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../user.service';
import { Cab } from '../cab';

@Component({
  selector: 'app-list-cab',
  templateUrl: './list-cab.component.html',
  styleUrls: ['./list-cab.component.css']
})
export class ListCabComponent implements OnInit {

  allCabs: Cab[] = [];  

  cabObj: Cab ={
    cabId:0,
    carType: '',
    perKmRate:15
  }

  myError = '';

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    this.userService.getAllCabs().subscribe((response) => {
      console.log(response);
      this.allCabs = response;
    },
    (error) => {
      console.log(error.error.message);
      this.myError = error.error.message;
    });
  }

  deleteCab(cabId: number){
    console.log(cabId);
    this.userService.deleteCab(cabId).subscribe((response) => {
      console.log(response);
      this.cabObj = response;
    },
    (error) => {
      console.log(error.error.message);
      this.allCabs = [];
      this.myError = error.error.message;
    });
  }

  editCab(cabId: number){
    console.log(cabId);
    this.router.navigate(['edit-cab', cabId])
  }
  


}
