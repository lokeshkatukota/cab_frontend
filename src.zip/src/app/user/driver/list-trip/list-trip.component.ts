import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../../trip/trip';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-list-trip',
  templateUrl: './list-trip.component.html',
  styleUrls: ['./list-trip.component.css']
})
export class ListTripComponent implements OnInit {

  allTripsList: Trip[]=[];

   addTripData: Trip = {
    tripBookingId: 0,
    fromLocation: '',
    toLocation: '',
    fromDateTime: '',
    toDateTime: '',
    distanceInKm:0,
    bill:0,
    status : '',
    
    customerEntity:{
      customerId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'customer'
      },
      customerUserName:'',
      customerPassword:'',
      customerAddress:'',
      customerMobileNumber:0,
      customerEmail:''
    },
    driverEntity:{
      driverId: 0,
      userId:{
        userId:0,
        username: '',
        password:'',
        role: 'driver'
      },
      driverUserName:'',
      driverPassword:'',
      driverAddress:'',
      driverMobileNumber:0,
      driverEmail:'',
      driverLicenceNumber:0,
      driverRating:0,
      cab:{
        cabId:0,
        carType:'',
        perKmRate:0,
      }
    }
}
  constructor(private userService:UserService , private router: Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let userId :any = this.activatedRoute.snapshot.paramMap.get('userId');
    console.log(userId);
 
      this.userService.getDriver(userId).subscribe((newDriver) => {
      console.log(newDriver);
      this.addTripData.driverEntity.driverId=newDriver.driverId;

      this.userService.getDriverTrips(this.addTripData.driverEntity.driverId).subscribe((response) =>{
        this.allTripsList=response;
        
      });
  });

  }

}
