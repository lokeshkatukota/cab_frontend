import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../user.service';
import { Cab } from '../cab';

@Component({
  selector: 'app-countcab',
  templateUrl: './countcab.component.html',
  styleUrls: ['./countcab.component.css']
})
export class CountcabComponent implements OnInit {

  //ADMIN FUNCTIONALITY
  
  car: Cab={
    cabId:0,
    carType: '',
    perKmRate:0
  }
 
  totalcount:number=0;

  constructor(private userService:UserService,private router:Router,private activatedRoute: ActivatedRoute) { }
  
  ngOnInit(): void {

  }

  count(carType:string) {
   
    this.userService.getCountCarsOfType(carType).subscribe((response) => {
      console.log(response);
      this.totalcount=response;
    });
    
  }

}
