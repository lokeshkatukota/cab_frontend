import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountcabComponent } from './countcab.component';

describe('CountcabComponent', () => {
  let component: CountcabComponent;
  let fixture: ComponentFixture<CountcabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CountcabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CountcabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
